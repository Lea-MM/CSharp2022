﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace LeaMarie_Magbalot_Exercise01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // populate the arrays with random values by calling the methods
            int[] integerArray = GetRandomIntegers();
            double[] doubleArray = GetRandomDoubles();
            char[] charArray = GetRandomChar();
            string[] stringArray = { "elohim", "ganymede", "deimos", "hephaestus", "menoetius", "lelantos", "midas", "pan", "jehova", "unknown" };

            // displays the possible values that user can search
            Console.WriteLine("-- Possible values to search --");
            Console.Write("Integer: ");
            foreach (int integer in integerArray)
            {
                Console.Write(integer + "\t");
            }

            Console.WriteLine();

            Console.Write("String:  ");
            foreach (string str in stringArray)
            {
                Console.Write(str + "   ");
            }

            Console.WriteLine("\n");

            // get user input for the search keyword
            Console.Write("Enter a search keyword: ");
            string input = Console.ReadLine().Trim();

            try
            {
                // search the keyword in the string and integer arrays 
                // display the index position

                int indexInStringArray = Search(stringArray, input);
                Console.WriteLine("\nResult: " + input + " is in position " + indexInStringArray + " of the string array.");

                int indexInIntegerArray = Search(integerArray, int.Parse(input));
                Console.WriteLine("Result: " + input + " is in position " + indexInIntegerArray + " of the integer array.\n");
            }
            catch (Exception)
            {
                Console.Write("Result: ");
                Console.ForegroundColor = ConsoleColor.DarkRed;
                Console.WriteLine("Error. Please enter a valid input to search the integer array!\n");
                Console.ForegroundColor = ConsoleColor.White;
            }
        }

        // method to compare the search key from the elements of an array
        public static int Search<T>(T[] dataArray, T searchKey) where T : IComparable<T>
        {
            for (int item = 0; item < dataArray.Length; item++)
            {
                if (dataArray[item].CompareTo(searchKey) == 0) // check if the current element is equal to the search key
                {
                    return item;    // return the index value of the current element
                }
            }
            return -1;  // return -1 if not found in the array
        }



        // method to get random integer numbers between 10 and 49
        public static int[] GetRandomIntegers()
        {
            // initialize array
            int[] intValues = new int[10];

            Random rnd = new Random();

            if (intValues[0] == 0)
            {
                intValues[0] = rnd.Next(11, 49);    // set the first element
            }

            for (int i = 1; i < 10; i++)
            {
                int nextIntValue = rnd.Next(11, 49);
                bool isExistInArray = false;

                foreach (int value in intValues)    // check to see if the next generated integer already exists in the array
                {
                    if (value == 0)
                        break;

                    if (value == nextIntValue)
                    {
                        isExistInArray = true;
                        break;
                    }
                }

                if (!isExistInArray)
                {
                    intValues[i] = nextIntValue;
                }
                else
                {
                    i--;
                }
            }

            return intValues;
        }

        // method to get random double numbers between 50 and 99
        public static double[] GetRandomDoubles()
        {
            // initialize array
            double[] doubleValues = new double[10];

            Random rnd = new Random();

            if (doubleValues[0] == 0)
            {
                doubleValues[0] = rnd.NextDouble() + rnd.Next(51, 99);    // set the first element
            }

            for (int i = 1; i < 10; i++)
            {
                double nextDoubleValue = rnd.NextDouble() + rnd.Next(51, 99);
                bool isExistInArray = false;

                foreach (int value in doubleValues)    // check to see if the next generated integer already exists in the array
                {
                    if (value == 0)
                        break;

                    if (value == nextDoubleValue)
                    {
                        isExistInArray = true;
                        break;
                    }
                }

                if (!isExistInArray)
                {
                    doubleValues[i] = nextDoubleValue;
                }
                else
                {
                    i--;
                }
            }

            return doubleValues;
        }

        // method to get random char between a and z
        public static char[] GetRandomChar()
        {
            char[] charValues = new char[10];

            Random rnd = new Random();

            if (charValues[0] == 0)
            {
                charValues[0] = (char)rnd.Next(97, 122);    // set the first element
            }

            for (int i = 1; i < 10; i++)
            {
                char nextCharValue = (char)rnd.Next(97, 122);
                bool isExistInArray = false;

                foreach (int value in charValues)    // check to see if the next generated integer already exists in the array
                {
                    if (value == 0)
                        break;

                    if (value == nextCharValue)
                    {
                        isExistInArray = true;
                        break;
                    }
                }

                if (!isExistInArray)
                {
                    charValues[i] = nextCharValue;
                }
                else
                {
                    i--;
                }
            }

            return charValues;
        }
    }
}
