﻿using LinkedListLibrary;
using QueueInheritanceLibrary;
using System;

namespace LeaMarie_Magbalot_Exercise03_QueueInheritanceLibrary
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // create list container for integers and doubles
            QueueInheritance intQueue = new QueueInheritance();
            QueueInheritance doubleQueue = new QueueInheritance();

            // create data to store in List
            int[] intArray = { 43, 67, 89, 34, 21, 11, 90, 150 };
            double[] doubleArray = { 10.5, 32.2, 9.0, 87.2, 2.6, 5.9 };

            // use Enqueue method to add items to queue
            foreach (int i in intArray)
            {
                intQueue.Enqueue<int>(i);
            }

            foreach (double d in doubleArray)
            {
                doubleQueue.Enqueue<double>(d);
            }

            try
            {
                // get the last element in the Queue
                Console.WriteLine("The last element in the integer linked list is " + intQueue.GetLastNode<int>());
                Console.WriteLine();
                Console.WriteLine("The last element in the double linked list is " + doubleQueue.GetLastNode<double>());
            }
            catch (EmptyListException emptyListException)
            {
                // if exception occurs, write stack trace
                Console.Error.WriteLine(emptyListException.StackTrace);
            }
        }
    }
}
