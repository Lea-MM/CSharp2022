﻿using LinkedListLibrary;

namespace QueueInheritanceLibrary
{
    // class QueueInheritance inherits List's capabilities
    public class QueueInheritance : List
    {
        // pass name "queue" to List constructor
        public QueueInheritance() : base("queue") { }

        // place dataValue at end of queue by inserting 
        // dataValue at end of linked list
        public void Enqueue<T>(T dataValue)
        {
            InsertAtBack(dataValue);
        }

        // remove item from front of queue by removing
        // item at front of linked list
        public T Dequeue<T>()
        {
            return RemoveFromFront<T>();
        }

        // method to return the last element in the queue but not delete it
        public T GetLasT<T>()
        {
            return GetLastNode<T>();
        }
    }
}
