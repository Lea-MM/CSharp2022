﻿using LinkedListLibrary;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LeaMarie_Magbalot_Exercise03_LinkedListLibraryTest
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var intList = new List(); // create List container for integers
            var doubleList = new List(); // create List container for doubles

            // create data to store in List
            int[] intArray = { 43, 67, 89, 34, 21, 11, 90, 150 };
            double[] doubleArray = { 10.5, 32.2, 9.0, 87.2, 2.6, 5.9 };

            // use List insert methods to add the elements at the back of the list
            foreach (int i in intArray)
            {
                intList.InsertAtBack(i);
            }

            foreach (double d in doubleArray)
            {
                doubleList.InsertAtBack(d);
            }

            // display the minimum and the last node of each list
            try
            {
                Console.WriteLine("The smallest node in the integer linked list is " + intList.Minimum<int>());
                Console.WriteLine("The last element in the integer linked list is " + intList.GetLastNode<int>());

                Console.WriteLine();

                Console.WriteLine("The smallest node in the double linked list is " + doubleList.Minimum<double>());
                Console.WriteLine("The last element in the double linked list is " + doubleList.GetLastNode<double>());
            }
            catch (EmptyListException emptyListException)
            {
                Console.Error.WriteLine($"\n{emptyListException}");
            }
        }
    }
}
