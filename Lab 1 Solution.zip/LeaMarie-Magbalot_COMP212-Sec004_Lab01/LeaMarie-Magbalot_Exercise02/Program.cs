﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LeaMarie_Magbalot_Exercise02
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // create an instance of StringBuilder and define the string to count the words
            StringBuilder stringBuilder = new StringBuilder("This is to test whether the extension method count can \r\nreturn a right answer or not");
            Console.WriteLine("Count of words: " + stringBuilder.CountWords());

            stringBuilder = new StringBuilder("You can define extension methods for user defined types as well as predefined types");
            Console.WriteLine("Count of words: " + stringBuilder.CountWords());
        }
    }
}
