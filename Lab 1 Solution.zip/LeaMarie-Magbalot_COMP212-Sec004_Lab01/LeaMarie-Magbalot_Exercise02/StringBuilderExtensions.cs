﻿using System.Text;

namespace LeaMarie_Magbalot_Exercise02
{
    public static class StringBuilderExtensions
    {
        // method to return the number of words in a given string
        public static int CountWords(this StringBuilder str)
        {
            var countedWords = 0;

            if (str.Length == 0)    
                return countedWords;

            // split the string input and store in a string array
            var splittedWords = str.ToString().Trim().Split(' ');
            for (int i = 0; i < splittedWords.Length; i++)
            {
                countedWords++;     // count number of elements in the array
            }

            return countedWords;
        }
    }
}
