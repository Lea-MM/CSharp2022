﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace LeaMarie_Magbalot_Exercise03
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // initialize a list variable
            List<int> listOfIntegers = new List<int>();
            Random random = new Random();

            try
            {
                // populate the listOfIntegers with 10 random numbers
                for (int i = 0; i < 10; i++)
                {
                    listOfIntegers.Add(random.Next(1, 100));
                }

                // displays the values of the list using the class Extensions
                Console.WriteLine("The values in the list are: ");
                listOfIntegers.Display();

                // displays the values of all numbers greater than 50 and add 10 to it
                Console.WriteLine("\nValues greater than 50 in sorted order after adding 10 are: ");
                listOfIntegers.Where(i => i > 50)   // find all numbers greater than 50
                              .Select(i => i + 10)  // add 10 to it
                              .OrderByDescending(i => i)    // order the results in descending order
                              .Display();   // display the result using the Extension class
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }


    // declares an extension method 
    static class Extensions
    {
        // extension method that displays all elements separated by spaces
        public static void Display<T>(this IEnumerable<T> data)
        {
            Console.WriteLine(string.Join(" ", data));
        }
    }
}
