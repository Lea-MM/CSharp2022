﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LeaMarie_Magbalot_Exercise05
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // populate the elements with random values from 1 to 500
            Random random = new Random();

            try
            {
                int[] elements = Enumerable.Range(1, 1000000)
                                       .Select(_ => random.Next(1, 501))
                                       .ToArray();

                // get the sum of all the elements in the array using LINQ and display the result
                Console.WriteLine("-- Using LINQ --");
                var time = Stopwatch.StartNew();
                Console.WriteLine($"Sum: {elements.Sum()}");
                Console.WriteLine($"Processing time: {time.ElapsedMilliseconds} ms");

                // get the distinct count of all the elements in the array using LINQ and display the result
                time.Restart();
                Console.WriteLine($"Distinct count: {elements.Distinct().Count()}");
                Console.WriteLine($"Processing time: {time.ElapsedMilliseconds} ms");

                Console.WriteLine();

                // get the sum of all the elements in the array using PLINQ and display the result
                Console.WriteLine("-- Using PLINQ --");
                time.Restart();
                Console.WriteLine($"Sum: {elements.AsParallel().Sum()}");
                Console.WriteLine($"Processing time: {time.ElapsedMilliseconds} ms");

                // get the distinct count of all the elements in the array using PLINQ and display the result
                time.Restart();
                Console.WriteLine($"Distinct count: {elements.AsParallel().Distinct().Count()}");
                Console.WriteLine($"Processing time: {time.ElapsedMilliseconds} ms");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
            
            Console.WriteLine();
        }
    }
}
