﻿using LeaMarie_Magbalot_Exercise01;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LeaMarie_Magbalot_Exercise01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // initialize the sample data for Invoice class objects
            var invoices = new List<Invoice>
            {
                new Invoice ( 87, "Electrical Sander", 7, 57.98m ),
                new Invoice ( 24, "Power Saw", 18, 99.99m ),
                new Invoice ( 7, "Sledge Hammer", 11, 21.50m ),
                new Invoice (77, "Hammer", 76, 11.99m ),
                new Invoice ( 39, "Lawn Mower", 3, 79.50m ),
                new Invoice ( 68, "Screw Driver", 106, 6.99m ),
                new Invoice (56, "Jig Saw", 21, 11.00m )
            };


            try
            {
                // 1st question
                // get the part description and total invoice value of each invoice
                var InvoiceTotal =
                    from invoice in invoices
                    let invoiceValue = invoice.Quantity * invoice.Price
                    orderby invoiceValue ascending
                    select new { invoice.PartDescription, invoiceValue };

                Console.WriteLine("Q1.");

                // display the InvoiceTotal
                foreach (var item in InvoiceTotal)
                {
                    Console.WriteLine($"Part Description: {item.PartDescription,-20}" + $"Invoice Total: {item.invoiceValue.ToString("C"),-2}");
                }


                Console.Write("\nQ2. ");


                // 2nd question
                // get the part description based on the highest quantity in the nested where clause
                var highestInvoice =
                    from invoice in invoices
                    where invoice.Quantity == (from i in invoices select i.Quantity).Max()
                    select invoice.PartDescription;

                // display a list of the highest invoice in the list 
                // items in the list can have the same number of quantities
                foreach (var item in highestInvoice)
                {
                    Console.WriteLine($"{item} has the highest quantity.");
                }


                Console.Write("\nQ3. ");


                // 3rd question
                // calculate the average price of the parts
                var averageInvoice =
                    (from invoice in invoices
                     select invoice.Price).Average();

                // display the average price of the parts
                Console.WriteLine($"The average price of the parts is {averageInvoice.ToString("C")} \n");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}
