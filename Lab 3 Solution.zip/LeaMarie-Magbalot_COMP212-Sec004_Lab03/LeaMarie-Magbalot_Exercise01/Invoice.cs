﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LeaMarie_Magbalot_Exercise01
{
    public class Invoice
    {
        // defines four auto-implemented properties
        public int PartNumber { get; set; }

        public string PartDescription { get; set; }

        public int Quantity { get; set; }

        public decimal Price { get; set; }


        // constructore to initialize the properties
        public Invoice(int partNumber, string partDescription, int quantity, decimal price)
        {
            PartNumber = partNumber;
            PartDescription = partDescription;
            Quantity = quantity;
            Price = price;
        }
    }
}
