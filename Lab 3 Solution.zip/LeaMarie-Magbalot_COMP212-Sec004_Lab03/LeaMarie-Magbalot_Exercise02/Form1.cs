﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LeaMarie_Magbalot_Exercise02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // event when calculate button is clicked
        private async void calculateFactorial_Click(object sender, EventArgs e)
        {
            int number = 0;

            try
            {
                number = (int)IsInputValid(numberToFactor.Text);    // check if user input is valid
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            factorialMessageLabel.Text = "Calculating...";

            // task to perform the factorial in a separate thread
            Task<BigInteger> factorialTask = Task.Run(() => CalculateFactorial(number));

            // wait for task in separate thread to complete
            await factorialTask;

            factorialMessageLabel.Text = factorialTask.Result.ToString();
        }

        // method to calculate the factorial of a number
        private BigInteger CalculateFactorial(int number)
        {
            BigInteger factoredNumber = number;

            for (int i = 1; i < (number - 1); i++)
            {
                factoredNumber *= number - i;
            }

            return factoredNumber;
        }

        // event when calculate interest is clicked
        private void CalculateInterest_Click(object sender, EventArgs e)
        {
            double loanAmountInput = 0;
            double interestRateInput = 0;
            int durationInput = 0;

            try
            {   // check if user input is valid
                loanAmountInput = IsInputValid(loanAmount.Text);    
                interestRateInput = IsInputValid(interestRate.Text);    
                durationInput = (int)IsInputValid(duration.Text);   
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

            // calculate the monthly payment
            double powerPortion = Math.Pow((1 + interestRateInput), durationInput);
            double monthlyPayment = loanAmountInput * ((interestRateInput * powerPortion) / (powerPortion - 1));

            // calculate the total interest and display
            double calculatedInterest = (monthlyPayment * durationInput) - loanAmountInput;
            loanMessageLabel.Text = String.Format("{0:C}", calculatedInterest);
        }

        // method to check for user input
        private double IsInputValid(string userInput)
        {
            double convertedNumber;

            if (!double.TryParse(userInput, out convertedNumber))
                throw new Exception("Please enter a valid input number!");

            return convertedNumber;
        }
    }
}
