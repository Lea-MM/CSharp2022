﻿namespace LeaMarie_Magbalot_Exercise02
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.factorialMessageLabel = new System.Windows.Forms.Label();
            this.calculateFactorial = new System.Windows.Forms.Button();
            this.numberToFactor = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.loanMessageLabel = new System.Windows.Forms.Label();
            this.CalculateInterest = new System.Windows.Forms.Button();
            this.duration = new System.Windows.Forms.TextBox();
            this.d = new System.Windows.Forms.Label();
            this.interestRate = new System.Windows.Forms.TextBox();
            this.ir = new System.Windows.Forms.Label();
            this.loanAmount = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.AutoSize = true;
            this.groupBox1.Controls.Add(this.factorialMessageLabel);
            this.groupBox1.Controls.Add(this.calculateFactorial);
            this.groupBox1.Controls.Add(this.numberToFactor);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.900001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(15, 15);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(10);
            this.groupBox1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.groupBox1.Size = new System.Drawing.Size(593, 441);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Calculate Asynchronously";
            // 
            // factorialMessageLabel
            // 
            this.factorialMessageLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.factorialMessageLabel.Location = new System.Drawing.Point(30, 335);
            this.factorialMessageLabel.Name = "factorialMessageLabel";
            this.factorialMessageLabel.Size = new System.Drawing.Size(530, 45);
            this.factorialMessageLabel.TabIndex = 8;
            this.factorialMessageLabel.Text = "output displayed here";
            this.factorialMessageLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // calculateFactorial
            // 
            this.calculateFactorial.BackColor = System.Drawing.SystemColors.ControlLight;
            this.calculateFactorial.Location = new System.Drawing.Point(122, 167);
            this.calculateFactorial.Name = "calculateFactorial";
            this.calculateFactorial.Size = new System.Drawing.Size(300, 80);
            this.calculateFactorial.TabIndex = 2;
            this.calculateFactorial.Text = "Calculate";
            this.calculateFactorial.UseVisualStyleBackColor = false;
            this.calculateFactorial.Click += new System.EventHandler(this.calculateFactorial_Click);
            // 
            // numberToFactor
            // 
            this.numberToFactor.Location = new System.Drawing.Point(330, 66);
            this.numberToFactor.Name = "numberToFactor";
            this.numberToFactor.Size = new System.Drawing.Size(250, 45);
            this.numberToFactor.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 72);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(274, 39);
            this.label1.TabIndex = 0;
            this.label1.Text = "Get Factorical of:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.loanMessageLabel);
            this.groupBox2.Controls.Add(this.CalculateInterest);
            this.groupBox2.Controls.Add(this.duration);
            this.groupBox2.Controls.Add(this.d);
            this.groupBox2.Controls.Add(this.interestRate);
            this.groupBox2.Controls.Add(this.ir);
            this.groupBox2.Controls.Add(this.loanAmount);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.900001F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(671, 15);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(844, 441);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Car Loan Calculator";
            // 
            // loanMessageLabel
            // 
            this.loanMessageLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.loanMessageLabel.Location = new System.Drawing.Point(46, 335);
            this.loanMessageLabel.Name = "loanMessageLabel";
            this.loanMessageLabel.Size = new System.Drawing.Size(720, 45);
            this.loanMessageLabel.TabIndex = 9;
            this.loanMessageLabel.Text = "interest displayed here";
            this.loanMessageLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // CalculateInterest
            // 
            this.CalculateInterest.BackColor = System.Drawing.SystemColors.ControlLight;
            this.CalculateInterest.Location = new System.Drawing.Point(602, 97);
            this.CalculateInterest.Name = "CalculateInterest";
            this.CalculateInterest.Size = new System.Drawing.Size(226, 149);
            this.CalculateInterest.TabIndex = 4;
            this.CalculateInterest.Text = "Calculate Interest";
            this.CalculateInterest.UseVisualStyleBackColor = false;
            this.CalculateInterest.Click += new System.EventHandler(this.CalculateInterest_Click);
            // 
            // duration
            // 
            this.duration.Location = new System.Drawing.Point(307, 232);
            this.duration.Name = "duration";
            this.duration.Size = new System.Drawing.Size(250, 45);
            this.duration.TabIndex = 5;
            // 
            // d
            // 
            this.d.AutoSize = true;
            this.d.Location = new System.Drawing.Point(105, 238);
            this.d.Name = "d";
            this.d.Size = new System.Drawing.Size(155, 39);
            this.d.TabIndex = 4;
            this.d.Text = "Duration:";
            // 
            // interestRate
            // 
            this.interestRate.Location = new System.Drawing.Point(307, 152);
            this.interestRate.Name = "interestRate";
            this.interestRate.Size = new System.Drawing.Size(250, 45);
            this.interestRate.TabIndex = 3;
            // 
            // ir
            // 
            this.ir.AutoSize = true;
            this.ir.Location = new System.Drawing.Point(39, 158);
            this.ir.Name = "ir";
            this.ir.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ir.Size = new System.Drawing.Size(220, 39);
            this.ir.TabIndex = 2;
            this.ir.Text = "Interest Rate:";
            // 
            // loanAmount
            // 
            this.loanAmount.Location = new System.Drawing.Point(307, 66);
            this.loanAmount.Name = "loanAmount";
            this.loanAmount.Size = new System.Drawing.Size(250, 45);
            this.loanAmount.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(23, 69);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(237, 39);
            this.label2.TabIndex = 0;
            this.label2.Text = " Loan Amount:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1547, 503);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox numberToFactor;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button calculateFactorial;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox loanAmount;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button CalculateInterest;
        private System.Windows.Forms.TextBox duration;
        private System.Windows.Forms.Label d;
        private System.Windows.Forms.TextBox interestRate;
        private System.Windows.Forms.Label ir;
        private System.Windows.Forms.Label factorialMessageLabel;
        private System.Windows.Forms.Label loanMessageLabel;
    }
}

