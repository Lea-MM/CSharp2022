﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LeaMarie_Magbalot_Exercise02
{
    internal class Program
    {
        // define a delegate 
        delegate bool GradesPredicate(double value);

        static void Main(string[] args)
        {
            // define the student's grade array
            double[] studentGrades = new double[10];
            Random random = new Random();

            // populate the sturdent's grade array with random values between 5 and 50 (excluding 5 and 50)
            for (int i = 0; i < 10; i++)
            {
                studentGrades[i] = random.NextDouble() + random.Next(6, 50);
            }

            // call the method and pass the student's grade array and 
            // the expression to evaluate if grade is greater than or equal to 15
            try
            {
                GradesFilter(studentGrades, grade => grade >= 15);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Something went wrong. " + ex.Message);
            }
        }

        static void GradesFilter(double[] doubleArray, GradesPredicate gradesPredicate)
        {
            Console.WriteLine("Grades that are greater than or equal to 15:");

            // iterate through the array and check if the grade is greater than or equal to 15
            for (int i = 0; i < doubleArray.Length; i++)
            {
                if (gradesPredicate(doubleArray[i]))    // use the predicate to check if grade is >= 15
                {
                    Console.WriteLine(doubleArray[i]);  
                }
            }
        }
    }
}
