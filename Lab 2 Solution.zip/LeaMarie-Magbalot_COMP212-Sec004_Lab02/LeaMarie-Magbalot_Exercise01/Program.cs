﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LeaMarie_Magbalot_Exercise01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // define the built-in delegates
            Func<string, string, string, string> minimum = Minimum;
            Action<int, int, int> avgGrade = AvgGrade;

            try
            {
                // test the Minimum method using built-in Func<>
                Console.WriteLine("Smallest string value: " + minimum("C# is the best course!", "This is a number", "I love doing programming challenges"));

                // test the AvgGrade method using built-in Action<>
                avgGrade(100, 75, 89);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Something went wrong. " + ex.Message);
            }
        }
        
        // method to return the smallest of three string values
        // the lambda first checks if string1 is less than string2
        // if true it checks if string1 is less than string3 and return string1 else string3
        // if false it checks if string2 is less than string3 and return string2 else string3
        static string Minimum(string string1, string string2, string string3) => string1.Length < string2.Length ? (string1.Length < string3.Length? string1 : string3) : (string2.Length < string3.Length? string2 : string3);


        // method to display the average of three grades
        static void AvgGrade(int value1, int value2, int value3) => Console.WriteLine("Average grade: " + ((value1 + value2 + value3) / 3));
    }
}
