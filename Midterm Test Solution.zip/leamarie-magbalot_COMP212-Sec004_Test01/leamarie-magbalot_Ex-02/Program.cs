﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace leamarie_magbalot_Ex_02
{
    internal class Program
    {
        static void Main(string[] args)
        {
            StringBuilder stringBuilder = new StringBuilder("This is a demo test");
            Console.WriteLine("Count of chars: " + stringBuilder.CharCount());
        }
    }
}
