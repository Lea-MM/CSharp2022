﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace leamarie_magbalot_Ex_02
{
    public static class StringBuilderExtensions
    {
        public static int CharCount(this StringBuilder str)
        {
            var countedChars = 0;

            if (str.Length == 0)
                return countedChars;

            // split the string input and store in a string array
            var splittedWords = str.ToString().ToCharArray();
            for (int i = 0; i < splittedWords.Length; i++)
            {
                countedChars++;     // count number of elements in the array
            }

            return countedChars;
        }
    }
}
