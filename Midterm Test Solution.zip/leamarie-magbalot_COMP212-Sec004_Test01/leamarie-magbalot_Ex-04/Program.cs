﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace leamarie_magbalot_Ex_04
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Action<string, string, string> largest = Largest;

            // call the method to get the largest string and display the result
            largest("advanced c# course for students", "C# fundamentals", "centennial college prop");
        }

        // method to get the largest string value and display the result
        static void Largest(string string1, string string2, string string3) => Console.WriteLine("Largest string value: " + (string1.Length > string2.Length ? (string1.Length > string3.Length ? string1 : string3) : (string2.Length > string3.Length ? string2 : string3)));

    }
}
