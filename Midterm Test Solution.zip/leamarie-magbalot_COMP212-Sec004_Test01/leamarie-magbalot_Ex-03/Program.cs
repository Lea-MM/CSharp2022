﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Text;
using System.Threading.Tasks;

namespace leamarie_magbalot_Ex_03
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // create the test data
            int[] intArray = new int[] {11, 22, 33, 44, 55};
            double[] doubleArray = new double[] { 11.1, 22.2, 33.3, 44.4, 55.5 };

            try
            {
                // try to get the sub arrays
                int[] ints = SubArray<int>(intArray, 4, 4);
                
                // display ints
                Console.Write("Integer values: ");
                foreach (int i in ints)
                {
                    Console.Write(i + " ");
                }               
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            try
            {
                // try to get the sub arrays
                double[] doubles = SubArray<double>(doubleArray, 0, 4);

                // display double
                Console.Write("\nDouble values: ");
                foreach (double i in doubles)
                {
                    Console.Write(i + " ");
                }

                Console.WriteLine();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        // mehtod to get the sub array
        public static T[] SubArray<T>(T[] a, int startIndex, int endIndex)
        {
            // check if the parameters are valid
            if (startIndex < 0 || startIndex > a.Length || startIndex > endIndex || startIndex == endIndex)
                throw new Exception("Startindex must be greater than 0 or less than the size of the array or end index");

            if (endIndex < 0 || endIndex > a.Length || endIndex < startIndex || startIndex == endIndex)
                throw new Exception("Endindex must be greater than 0 or less than the size of the array or end index");


            T[] values = new T[(endIndex + 1) - 2]; 
            int position = 0;

            // iterate through the array and get the values
            for (int i = 0; i < a.Length; i++)
            {
                if (i > startIndex && i < endIndex)
                {
                    values[position] = a[i];
                    position++;
                }
            }

            return values;
        }
    }
}
