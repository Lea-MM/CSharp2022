﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace leamarie_magbalot_Ex_01
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Recursively calculates Fibonacci numbers
        public long Fibonacci(long n)
        {
            if (n == 0 || n == 1)
            {
                return n;
            }
            else
            {
                return Fibonacci(n - 1) + Fibonacci(n - 2);
            }
        }

        // method to calculate the factorial of a number
        private BigInteger Factorial(int number)
        {
            BigInteger factoredNumber = number;

            for (int i = 1; i < (number - 1); i++)
            {
                factoredNumber *= number - i;
            }

            return factoredNumber;
        }

        // append text to outputTextBox in UI thread
        public void AppendText(String text)
        {
            if (InvokeRequired) // not GUI thread, so add to GUI thread
            {
                Invoke(new MethodInvoker(() => AppendText(text)));
            }
            else // GUI thread so append text
            {
                outputTextBox.AppendText(text + "\r\n");
            }
        }

        private async void buttonClick_Click(object sender, EventArgs e)
        {
            outputTextBox.Text = "Starting Task to calculate Fibonacci(43)\r\n";
            outputTextBox.AppendText("Starting Task to calculate Factorial(100)\r\n");

            // create Task to perform Fibonacci(43) calculation in a thread
            Task<long> task1 = Task.Run(() => Fibonacci(43));
            outputTextBox.AppendText("Calculating Fibonacci(43)\r\n");

            // create Task to perform Factorial(100) calculation in a thread
            Task<BigInteger> task2 = Task.Run(() => Factorial(100));
            outputTextBox.AppendText("Calculating Factorial(100)\r\n");

            await Task.WhenAll(task1, task2);

            outputTextBox.AppendText("Fibonacci(43): " + task1.Result + "\r\n");
            outputTextBox.AppendText("Factorial(100): " + task2.Result);
        }
    }
}
