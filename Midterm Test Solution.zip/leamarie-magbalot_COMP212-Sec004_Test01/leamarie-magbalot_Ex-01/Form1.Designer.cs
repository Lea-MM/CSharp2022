﻿namespace leamarie_magbalot_Ex_01
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonClick = new System.Windows.Forms.Button();
            this.outputTextBox = new System.Windows.Forms.TextBox();
            this.title = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // buttonClick
            // 
            this.buttonClick.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonClick.Location = new System.Drawing.Point(72, 164);
            this.buttonClick.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.buttonClick.Name = "buttonClick";
            this.buttonClick.Size = new System.Drawing.Size(776, 55);
            this.buttonClick.TabIndex = 5;
            this.buttonClick.Text = "Click for Asynchronous Calls to two methods Fibonacci and Factorial";
            this.buttonClick.UseVisualStyleBackColor = true;
            this.buttonClick.Click += new System.EventHandler(this.buttonClick_Click);
            // 
            // outputTextBox
            // 
            this.outputTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.outputTextBox.Location = new System.Drawing.Point(75, 233);
            this.outputTextBox.Margin = new System.Windows.Forms.Padding(8, 7, 8, 7);
            this.outputTextBox.Multiline = true;
            this.outputTextBox.Name = "outputTextBox";
            this.outputTextBox.Size = new System.Drawing.Size(767, 450);
            this.outputTextBox.TabIndex = 4;
            // 
            // title
            // 
            this.title.AutoSize = true;
            this.title.Location = new System.Drawing.Point(75, 123);
            this.title.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.title.Name = "title";
            this.title.Size = new System.Drawing.Size(777, 32);
            this.title.TabIndex = 3;
            this.title.Text = "Calls to Fibonacci(43) and Factorial(100) in separate threads";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(921, 807);
            this.Controls.Add(this.buttonClick);
            this.Controls.Add(this.outputTextBox);
            this.Controls.Add(this.title);
            this.Name = "Form1";
            this.Text = "Asynchronous Test";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button buttonClick;
        private System.Windows.Forms.TextBox outputTextBox;
        private System.Windows.Forms.Label title;
    }
}

